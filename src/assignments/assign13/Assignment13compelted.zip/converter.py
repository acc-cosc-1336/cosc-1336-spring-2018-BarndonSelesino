class Converter:
    def get_miles_from_km(self, km):
        cf = 0.621371
        miles = km * cf
        return (miles)
